package com.example.myapplication.repository

import com.example.myapplication.database.NoteDatabase
import com.example.myapplication.model.Note

class NoteRepository(private val db:NoteDatabase) {

    suspend fun insertNote(note: Note) = db.getNoteDao().insertNote(note)
    suspend fun deletetNote(note: Note) = db.getNoteDao().deleteNote(note)
    suspend fun updateNote(note: Note) = db.getNoteDao().updateNote(note)

    fun getAllNotes() = db.getNoteDao().getAllNotes()
    suspend fun searchNote(query: String?) = db.getNoteDao().searchNote(query)


}